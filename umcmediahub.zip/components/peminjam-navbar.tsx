"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Home, Package, Calendar, CreditCard, RotateCcw, MessageSquare, Bell, User, Camera } from "lucide-react"

const peminjamMenuItems = [
  {
    title: "Beranda",
    href: "/dashboard",
    icon: Home,
  },
  {
    title: "Aset & Jasa",
    href: "/inventory",
    icon: Package,
  },
  {
    title: "Booking Saya",
    href: "/bookings",
    icon: Calendar,
  },
  {
    title: "Pembayaran",
    href: "/payments",
    icon: CreditCard,
  },
  {
    title: "Pengembalian",
    href: "/returns",
    icon: RotateCcw,
  },
  {
    title: "Feedback",
    href: "/feedback",
    icon: MessageSquare,
  },
  {
    title: "Notifikasi",
    href: "/notifications",
    icon: Bell,
  },
  {
    title: "Profil",
    href: "/settings/profile",
    icon: User,
  },
]

export function PeminjamNavbar() {
  const pathname = usePathname()

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/dashboard" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl flex items-center justify-center">
              <Camera className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
                UMC Media Hub
              </h1>
            </div>
          </Link>

          {/* Navigation Menu */}
          <div className="hidden md:flex items-center space-x-1">
            {peminjamMenuItems.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + "/")
              const Icon = item.icon

              return (
                <Button
                  key={item.href}
                  asChild
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className={cn(
                    "gap-2 rounded-xl font-medium transition-all duration-200",
                    isActive
                      ? "bg-gradient-to-r from-indigo-500 to-violet-600 text-white shadow-lg hover:from-indigo-600 hover:to-violet-700"
                      : "text-gray-700 hover:bg-gray-100 hover:text-gray-900",
                  )}
                >
                  <Link href={item.href}>
                    <Icon className="w-4 h-4" />
                    {item.title}
                  </Link>
                </Button>
              )
            })}
          </div>

          {/* Mobile menu button - placeholder for future implementation */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" className="rounded-xl">
              <Package className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
