"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { DataTable } from "@/components/data-table"
import { StatusBadge } from "@/components/status-badge"
import { useAuth } from "@/contexts/auth-context"
import { mockPayments, mockBookings, mockUsers } from "@/lib/mock"
import { PaymentStatus, PaymentMethod, Role } from "@/types"
import { formatCurrency, formatDateTime } from "@/lib/format"
import { Upload, CreditCard, Eye } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function PaymentsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [statusFilter, setStatusFilter] = useState("")
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false)
  const [selectedPayment, setSelectedPayment] = useState<any>(null)
  const [proofFile, setProofFile] = useState<File | null>(null)
  const [newStatus, setNewStatus] = useState("")

  const isAdmin = user?.role === Role.ADMIN

  // Get payments with booking and user details
  const paymentsWithDetails = mockPayments
    .map((payment) => {
      const booking = mockBookings.find((b) => b.id === payment.bookingId)
      const bookingUser = booking ? mockUsers.find((u) => u.id === booking.userId) : null

      return {
        ...payment,
        bookingCode: booking?.id.slice(-8) || "Unknown",
        userName: bookingUser?.name || "Unknown",
        userEmail: bookingUser?.email || "",
        bookingStartDate: booking?.startDatetime || "",
      }
    })
    .filter((payment) =>
      isAdmin ? true : mockBookings.some((b) => b.id === payment.bookingId && b.userId === user?.id),
    )
    .filter((payment) => !statusFilter || statusFilter === "all" || payment.status === statusFilter)
    .sort((a, b) => new Date(b.paidAt || "1970-01-01").getTime() - new Date(a.paidAt || "1970-01-01").getTime())

  // Define columns for payments table
  const paymentColumns = [
    {
      key: "bookingCode",
      title: "Booking",
      render: (value: string) => <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded-md">{value}</span>,
    },
    ...(isAdmin
      ? [
          {
            key: "userName",
            title: "Pengguna",
            render: (value: string, item: any) => (
              <div>
                <p className="font-medium">{value}</p>
                <p className="text-sm text-gray-500">{item.userEmail}</p>
              </div>
            ),
          },
        ]
      : []),
    {
      key: "amount",
      title: "Jumlah",
      render: (value: number) => formatCurrency(value),
    },
    {
      key: "method",
      title: "Metode",
      render: (value: string) => {
        const methodLabels = {
          [PaymentMethod.CASH]: "Tunai",
          [PaymentMethod.TRANSFER]: "Transfer",
          [PaymentMethod.QRIS]: "QRIS",
        }
        return methodLabels[value as PaymentMethod] || value
      },
    },
    {
      key: "status",
      title: "Status",
      render: (value: string) => <StatusBadge status={value} />,
    },
    {
      key: "paidAt",
      title: "Tanggal Bayar",
      render: (value: string) => (value ? formatDateTime(value) : "-"),
      sortable: true,
    },
    {
      key: "referenceNo",
      title: "Referensi",
      render: (value: string) => value || "-",
    },
    {
      key: "actions",
      title: "Aksi",
      render: (_: any, payment: any) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setSelectedPayment(payment)
              setNewStatus(payment.status)
              setPaymentDialogOpen(true)
            }}
            className="rounded-lg"
          >
            {payment.status === PaymentStatus.PENDING ? <Upload className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </Button>
        </div>
      ),
    },
  ]

  const handleUpdatePayment = () => {
    if (!selectedPayment) return

    // In a real app, this would make an API call
    console.log("Updating payment:", {
      id: selectedPayment.id,
      status: newStatus,
      proofFile,
    })

    toast({
      title: "Berhasil",
      description: "Status pembayaran berhasil diperbarui",
    })

    setPaymentDialogOpen(false)
    setSelectedPayment(null)
    setProofFile(null)
    setNewStatus("")
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Pembayaran</h1>
        <p className="text-gray-600 mt-2">
          {isAdmin ? "Kelola pembayaran dari semua pengguna" : "Lihat status pembayaran Anda"}
        </p>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 p-4 bg-white rounded-2xl shadow-sm border">
        <CreditCard className="w-5 h-5 text-gray-400" />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48 rounded-xl">
            <SelectValue placeholder="Semua Status" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="all" className="rounded-lg">
              Semua Status
            </SelectItem>
            <SelectItem value={PaymentStatus.PENDING} className="rounded-lg">
              Pending
            </SelectItem>
            <SelectItem value={PaymentStatus.PAID} className="rounded-lg">
              Lunas
            </SelectItem>
            <SelectItem value={PaymentStatus.FAILED} className="rounded-lg">
              Gagal
            </SelectItem>
            <SelectItem value={PaymentStatus.REFUNDED} className="rounded-lg">
              Dikembalikan
            </SelectItem>
          </SelectContent>
        </Select>
        <div className="text-sm text-gray-500">Menampilkan {paymentsWithDetails.length} pembayaran</div>
      </div>

      {/* Payments Table */}
      <DataTable
        data={paymentsWithDetails}
        columns={paymentColumns}
        searchPlaceholder="Cari pembayaran..."
        pageSize={10}
      />

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>
              {selectedPayment?.status === PaymentStatus.PENDING ? "Upload Bukti Pembayaran" : "Detail Pembayaran"}
            </DialogTitle>
            <DialogDescription>
              {selectedPayment?.status === PaymentStatus.PENDING
                ? "Upload bukti pembayaran dan ubah status"
                : "Lihat detail pembayaran"}
            </DialogDescription>
          </DialogHeader>

          {selectedPayment && (
            <div className="space-y-6">
              {/* Payment Details */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Booking</p>
                    <p className="font-medium">{selectedPayment.bookingCode}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Jumlah</p>
                    <p className="font-medium">{formatCurrency(selectedPayment.amount)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Metode</p>
                    <p className="font-medium">{selectedPayment.method}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Status Saat Ini</p>
                    <StatusBadge status={selectedPayment.status} />
                  </div>
                </div>
              </div>

              {/* Proof Upload */}
              {selectedPayment.status === PaymentStatus.PENDING && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="proof">Bukti Pembayaran</Label>
                    <Input
                      id="proof"
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => setProofFile(e.target.files?.[0] || null)}
                      className="rounded-xl"
                    />
                  </div>

                  {isAdmin && (
                    <div className="space-y-2">
                      <Label htmlFor="status">Status Baru</Label>
                      <Select value={newStatus} onValueChange={setNewStatus}>
                        <SelectTrigger className="rounded-xl">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="rounded-xl">
                          <SelectItem value={PaymentStatus.PENDING} className="rounded-lg">
                            Pending
                          </SelectItem>
                          <SelectItem value={PaymentStatus.PAID} className="rounded-lg">
                            Lunas
                          </SelectItem>
                          <SelectItem value={PaymentStatus.FAILED} className="rounded-lg">
                            Gagal
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              )}

              {/* Existing Proof */}
              {selectedPayment.proofUrl && (
                <div className="space-y-2">
                  <Label>Bukti Pembayaran</Label>
                  <div className="p-4 border rounded-xl">
                    <p className="text-sm text-gray-600">File bukti pembayaran tersedia</p>
                    <Button variant="outline" size="sm" className="mt-2 rounded-lg bg-transparent">
                      Lihat Bukti
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setPaymentDialogOpen(false)} className="rounded-xl">
              Tutup
            </Button>
            {selectedPayment?.status === PaymentStatus.PENDING && (
              <Button
                onClick={handleUpdatePayment}
                className="rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700"
              >
                {isAdmin ? "Update Status" : "Upload Bukti"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
